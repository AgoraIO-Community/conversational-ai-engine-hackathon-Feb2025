import json
import urllib.request
import urllib.error
import os

def lambda_handler(event, context):
    print(event)
    # get agent join params from request body
    parsed_data = json.loads(event['body'])
    agentname = parsed_data.get("agentname")
    channel = parsed_data.get("channel")
    agentuid = parsed_data.get("agentuid")
    remoteuid = parsed_data.get("remoteuid")
    prompt = parsed_data.get("prompt")
    message = parsed_data.get("message")

    # os environ variables
    appid = os.environ.get("APP_ID")

    if not agentname or not channel or not agentuid or not remoteuid or not prompt or not message:
        return {
        'statusCode': 503,
        'body': "check the agent join body params"
    }

    url = f"https://api.agora.io/api/conversational-ai-agent/v2/projects/{appid}/join"
    headers = {
        'Content-Type': 'application/json',
        'Authorization': os.environ.get("AGORA_REST_AUTH")
    }
    
    data = {
	"name":agentname,
	"properties":{
		"channel":channel,
		"token":"",
		"agent_rtc_uid":agentuid,
		"enable_string_uid": "true",
		"idle_timeout":120,
		"remote_rtc_uids":[remoteuid],
		"advanced_features":{
			"enable_bhvs":"true",
			"enable_aivad":"true"
	},
	"asr":{
		"language":"en-US"
	},
	"vad":{
		"silence_duration_ms":480
	},
	"llm":{
		"url":os.environ.get("URL"),
		"api_key":os.environ.get("LLM_KEY"),
		"system_messages":[{
			"role":"system",
			"content":prompt
		}],
		"greeting_message":message,
		"failure_message":"Sorry, something went wrong, the game is cancelled.",
		"max_history":10,
		"params":{
			"model":os.environ.get("MODEL"),
			"max_completion_tokens":1000
		}},
		"tts":{
			"vendor":os.environ.get("TTS_VENDOR"),
			"params":{
				"key":os.environ.get("TTS_KEY"),
				"region":os.environ.get("TTS_REGION"),
				"voice_name":os.environ.get("TTS_VOICE"),
				"rate":1,
				"volume":70
			}
		}
	}
}
    
    try:
        # Convert data dict to JSON string and encode to bytes
        data = json.dumps(data).encode('utf-8')
        
        # Create a Request object with the URL, data, and headers
        req = urllib.request.Request(
            url=url,
            data=data,  # Add the POST data
            headers=headers,
            method='POST'  # Specify the POST method
        )
        
        # Make the request and get the response
        with urllib.request.urlopen(req) as response:
            # Read and decode the response
            data = response.read().decode('utf-8')
            # Parse JSON response
            json_data = json.loads(data)

            return {
                'statusCode': 200,
                'body': json.dumps(json_data)
            }

    except urllib.error.HTTPError as e:
        return {
            'statusCode': e.code,
            'body': json.dumps({'error': str(e)})
        }
    except urllib.error.URLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }